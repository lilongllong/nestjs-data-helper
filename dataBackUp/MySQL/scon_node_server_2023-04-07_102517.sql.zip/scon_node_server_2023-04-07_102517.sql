/*!40101 SET NAMES utf8 */;
/*!40014 SET FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET SQL_NOTES=0 */;
DROP TABLE IF EXISTS community_db;
CREATE TABLE `community_db` (
  `id` int NOT NULL AUTO_INCREMENT,
  `communityName` text NOT NULL,
  `districtname` text NOT NULL,
  `zoneName` text NOT NULL,
  `createTime` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `hot` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1791 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS nominal_price_db;
CREATE TABLE `nominal_price_db` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ref_id` int NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `layout` varchar(255) NOT NULL,
  `orientation` varchar(255) NOT NULL,
  `estate` varchar(255) NOT NULL,
  `tags` varchar(255) NOT NULL,
  `originalUrl` varchar(255) NOT NULL,
  `site` varchar(255) NOT NULL,
  `data` varchar(255) NOT NULL DEFAULT '',
  `changeType` varchar(255) NOT NULL,
  `changeDay` varchar(255) NOT NULL,
  `houseId` varchar(255) NOT NULL,
  `changeRate` float NOT NULL DEFAULT '0',
  `acreage` float NOT NULL DEFAULT '0',
  `refPrice` float NOT NULL DEFAULT '0',
  `price` float NOT NULL DEFAULT '0',
  `unitPrice` float NOT NULL DEFAULT '0',
  `refScale` float NOT NULL DEFAULT '0',
  `changePrice` float NOT NULL DEFAULT '0',
  `createTime` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13030 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS sales_db;
CREATE TABLE `sales_db` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ref_id` int NOT NULL DEFAULT '0',
  `district` text NOT NULL,
  `name` text NOT NULL,
  `roomCount` int NOT NULL,
  `acreage` float NOT NULL DEFAULT '0',
  `price` float NOT NULL DEFAULT '0',
  `cycle` float NOT NULL DEFAULT '0',
  `date` text NOT NULL,
  `unitPrice` float NOT NULL DEFAULT '0',
  `site` text NOT NULL,
  `createTime` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `area` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=86951 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS schedule_mark_db;
CREATE TABLE `schedule_mark_db` (
  `id` int NOT NULL AUTO_INCREMENT,
  `desc` text NOT NULL,
  `name` text NOT NULL,
  `mark` text NOT NULL,
  `process` float NOT NULL DEFAULT '0',
  `updateTime` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

DROP TABLE IF EXISTS user;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `firstName` varchar(255) NOT NULL,
  `lastName` varchar(255) NOT NULL,
  `isActive` tinyint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;